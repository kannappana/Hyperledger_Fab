#!/bin/bash

#Key Store Creation
keytool -keystore server0.keystore.jks -alias kafka0 -validity 365 -genkey -keyalg RSA -keysize 2048 -storepass test1234 -dname "cn=kafka0.example.com" -keypass test1234
keytool -keystore server1.keystore.jks -alias kafka1 -validity 365 -genkey -keyalg RSA -keysize 2048 -storepass test1234 -dname "cn=kafka1.example.com" -keypass test1234
keytool -keystore server2.keystore.jks -alias kafka2 -validity 365 -genkey -keyalg RSA -keysize 2048 -storepass test1234 -dname "cn=kafka2.example.com" -keypass test1234

keytool -keystore client.keystore.jks -alias orderer -validity 365 -genkey -keyalg RSA -keysize 2048 -storepass test1234 -dname "cn=orderer.example.com" -keypass test1234

Key pair for ROOTCA 
openssl req -new -x509 -keyout ca-key.pem -out ca-cert.pem -days 365 -subj "/CN=FAB5226" -nodes

#Importing the CA Certificate in Trust Stores 
keytool -keystore server0.truststore.jks -alias CARoot -import -file ca-cert.pem -storepass test1234 -noprompt
keytool -keystore server1.truststore.jks -alias CARoot -import -file ca-cert.pem -storepass test1234 -noprompt
keytool -keystore server2.truststore.jks -alias CARoot -import -file ca-cert.pem -storepass test1234 -noprompt
keytool -keystore client.truststore.jks -alias CARoot -import -file ca-cert.pem -storepass test1234 -noprompt

#Certificate request for the kafka
keytool -keystore server0.keystore.jks -alias kafka0 -certreq -file server0-cert-signing-request.pem -storepass test1234
keytool -keystore server1.keystore.jks -alias kafka1 -certreq -file server1-cert-signing-request.pem -storepass test1234
keytool -keystore server2.keystore.jks -alias kafka2 -certreq -file server2-cert-signing-request.pem -storepass test1234

#Getting the certificate 
openssl x509 -req -CA ca-cert.pem -CAkey ca-key.pem -in server0-cert-signing-request.pem -out server0-cert-signed.pem -days 365 -CAcreateserial -passin pass:test1234
openssl x509 -req -CA ca-cert.pem -CAkey ca-key.pem -in server1-cert-signing-request.pem -out server1-cert-signed.pem -days 365 -CAcreateserial -passin pass:test1234
openssl x509 -req -CA ca-cert.pem -CAkey ca-key.pem -in server2-cert-signing-request.pem -out server2-cert-signed.pem -days 365 -CAcreateserial -passin pass:test1234

keytool -keystore server0.keystore.jks -alias CARoot -import -file ca-cert.pem -storepass test1234 -noprompt
keytool -keystore server0.keystore.jks -alias kafka0 -import -file server0-cert-signed.pem -storepass test1234 -noprompt

keytool -keystore server1.keystore.jks -alias CARoot -import -file ca-cert.pem -storepass test1234 -noprompt
keytool -keystore server1.keystore.jks -alias kafka1 -import -file server1-cert-signed.pem -storepass test1234 -noprompt

keytool -keystore server2.keystore.jks -alias CARoot -import -file ca-cert.pem -storepass test1234 -noprompt
keytool -keystore server2.keystore.jks -alias kafka2 -import -file server2-cert-signed.pem -storepass test1234 -noprompt


#Certificate request for the orderer
keytool -keystore client.keystore.jks -alias orderer -certreq -file client-cert-signing-request.pem -storepass test1234
#Getting the certificate 
openssl x509 -req -CA ca-cert.pem -CAkey ca-key.pem -in client-cert-signing-request.pem -out client-cert-signed.pem -days 365 -CAcreateserial -passin pass:test1234

#Conversion of keystore
keytool -importkeystore -srckeystore client.keystore.jks -destkeystore client.keystore.p12 -deststoretype PKCS12 -storepass test1234 -srcstorepass test1234
openssl pkcs12 -in client.keystore.p12 -nodes -nocerts -out client-key.pem -passin pass:test1234

chmod 777 *
