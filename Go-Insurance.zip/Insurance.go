/*
Copyright IBM Corp. 2016 All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

		 http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/


package main


import (
	"fmt"
	"strconv"
	"encoding/json"
	"time"
	"strings"
	"bytes"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
	"github.com/shopspring/decimal"
)

var logger = shim.NewLogger("insurance_cc")
// SimpleChaincode example simple Chaincode implementation
type SimpleChaincode struct {
}

type Policy struct {
	PNR string `json:"PNR"`
	FlightNo string `json:"FlightNo"`
	DepartureDate string `json:"DepartureDate"`
	DepartureTime string `json:"DepartureTime"`
	PassengerName string `json:"eventType"`
}

type Departure struct {
	PNR string `json:"PNR"`
	FlightNo string `json:"FlightNo"`
	ActualDepartureDate string `json:"DepartureDate"`
	ActualDepartureTime string `json:"DepartureTime"`
}

type Meta struct {
  Version string
}

const version = "Version 2.0"

func (t *SimpleChaincode) Init(stub shim.ChaincodeStubInterface) pb.Response  {
	logger.Info("########### Insurance Init ###########")

	_, args := stub.GetFunctionAndParameters()

	if len(args) != 2 {
		return shim.Error("Incorrect number of arguments. Expecting 2")
	}

	if args[0] == "addInsurance" {
		//adds an event
		return t.addInsurance(stub, args)
	}

	return shim.Success(nil)
}

func (t *SimpleChaincode) Invoke(stub shim.ChaincodeStubInterface) pb.Response {
	logger.Info("########### event_cc Invoke ###########")

	function, args := stub.GetFunctionAndParameters()

	if function == "getVersion" {
		return t.getVersion(stub, args)
	} else if function == "addInsurance" {
		return t.addInsurance(stub, args)
    } else if function == "queryInsurance" {
		return t.queryInsurance(stub, args)
    } else if function == "addDeparturedDetails" {
		return t.claimInsurance(stub, args)
    } else if function == "queryDeparturedDetails" {
		return t.claimInsurance(stub, args)
    }

    logger.Errorf("Unknown action, check the first argument. Got: %v", args[0])
	return shim.Error(fmt.Sprintf("Unknown action, check the first argument. Got: %v", args[0]))

}

func (t *SimpleChaincode) getVersion(stub shim.ChaincodeStubInterface, args []string) pb.Response {

	scVersion := &Meta{Version: version}
	
	if scVersion == nil {
		return shim.Error("Smart Contract Version Not Available")
	} 
	
	scVersionAsBytes := []byte(version)
	
	if string(scVersionAsBytes) == "" {
		return shim.Error("Smart Contract Version Not Available")
	}

	return shim.Success(scVersionAsBytes)
}


func (t *SimpleChaincode) addInsurance(stub shim.ChaincodeStubInterface, args []string) pb.Response {

	var jsonResp string
	var err error

	if len(args) != 2 {
		return shim.Error("Incorrect number of arguments. Expecting 2. name of the key and value")
	}

    var policy Policy
	//map eventjson to model
	policyUM := json.Unmarshal([]byte(args[1]), &policy)
    if policyUM != nil {
        return shim.Error(policyUM.Error())
    }

    //insurance validations
    validatePNR := validate(policy.PNR, "string", "PNR", 5)
	if (validatePNR != "true") {
		jsonResp = "{\"Error\":\"" + validatePNR + "\"}"
		return shim.Error(jsonResp)
	}
    validateFlightNo := validate(policy.FlightNo, "string", "FlightNo", 5)
	if (validateFlightNo != "true") {
		jsonResp = "{\"Error\":\"" + validateFlightNo + "\"}"
		return shim.Error(jsonResp)
	}
    validateDepartureDate := validate(policy.DepartureDate, "string", "DepartureDate", 5)
	if (validateDepartureDate != "true") {
		jsonResp = "{\"Error\":\"" + validateDepartureDate + "\"}"
		return shim.Error(jsonResp)
	}
    validateDepartureTime := validate(policy.DepartureTime, "string", "DepartureTime", 5)
	if (validateDepartureTime != "true") {
		jsonResp = "{\"Error\":\"" + validateDepartureTime + "\"}"
		return shim.Error(jsonResp)
	}
    validatePassengerName := validate(policy.PassengerName, "string", "PassengerName", 5)
	if (validatePassengerName != "true") {
		jsonResp = "{\"Error\":\"" + validatePassengerName + "\"}"
		return shim.Error(jsonResp)
	}

    policyStr := `{"PNR": "` + policy.PNR + `", "FlightNo": "` + policy.FlightNo + `", "DepartureDate": "` + policy.DepartureDate + `", "DepartureTime": "` + policy.DepartureTime + `",
     "PassengerName": "` + policy.PassengerName + `"}`

    err = stub.PutState("Insurance", []byte(policyStr))
	if err != nil {
		return shim.Error(err.Error())
	}
	
    return shim.Success(nil);
}

//Query functions
func (t *SimpleChaincode) queryInsurance(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	
	var key, jsonResp string
	var err error
	
	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting name of the key to query")
	}
	
	key = "Insurance"
	valAsbytes, err := stub.GetState(key)
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to get state for " + key + "\"}"
		return shim.Error(jsonResp)
	}

	return shim.Success(valAsbytes)
}


func (t *SimpleChaincode) addDeparturedDetails(stub shim.ChaincodeStubInterface, args []string) pb.Response {
    var jsonResp string
	var err error

	if len(args) != 2 {
		return shim.Error("Incorrect number of arguments. Expecting 2. name of the key and value")
	}

    var ADT Departure
	//map eventjson to model
	depUM := json.Unmarshal([]byte(args[1]), &ADT)
    if depUM != nil {
        return shim.Error(policyUM.Error())
    }

    //insurance validations
    validatePNR := validate(ADT.PNR, "string", "PNR", 5)
	if (validatePNR != "true") {
		jsonResp = "{\"Error\":\"" + validatePNR + "\"}"
		return shim.Error(jsonResp)
	}
    validateFlightNo := validate(ADT.FlightNo, "string", "FlightNo", 5)
	if (validateFlightNo != "true") {
		jsonResp = "{\"Error\":\"" + validateFlightNo + "\"}"
		return shim.Error(jsonResp)
	}
    validateActualDepartureDate := validate(ADT.ActualDepartureDate, "string", "ActualDepartureDate", 5)
	if (validateActualDepartureDate != "true") {
		jsonResp = "{\"Error\":\"" + validateActualDepartureDate + "\"}"
		return shim.Error(jsonResp)
	}
    validateActualDepartureTime := validate(ADT.ActualDepartureTime, "string", "ActualDepartureTime", 5)
	if (validateActualDepartureTime != "true") {
		jsonResp = "{\"Error\":\"" + validateActualDepartureTime + "\"}"
		return shim.Error(jsonResp)
	}

    ADPStr := `{"PNR": "` + ADT.PNR + `", "FlightNo": "` + ADT.FlightNo + `", "DepartureDate": "` + ADT.ActualDepartureDate + `", "DepartureTime": "` + ADT.ActualDepartureTime + `"}`

    err = stub.PutState(ADT.PNR, []byte(ADPStr))
	if err != nil {
		return shim.Error(err.Error())
	}
	
    return shim.Success(nil);

}

func (t *SimpleChaincode) queryDeparturedDetails(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	
	var key, jsonResp string
	var err error
	
	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting name of the key to query")
	}
	
	key = args[0]
	valAsbytes, err := stub.GetState(key)
	if err != nil {
		jsonResp = "{\"Error\":\"Failed to get state for " + key + "\"}"
		return shim.Error(jsonResp)
	}

	return shim.Success(valAsbytes)
}